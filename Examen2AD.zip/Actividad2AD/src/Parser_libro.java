
public class Parser_libro {

	public static void main(String[] args) {
		
			Parser parse = new Parser();
			parse.parseFicheroXml("biblioteca.xml");
			parse.parseDocument();
			parse.print();

	}

}
