import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Parser {

	private Document dom = null;
	private ArrayList<libro> libros = null;

	public Parser() {
		libros = new ArrayList<libro>();
	}

	public void parseFicheroXml(String fichero) {
		// creamos una factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {
			// creamos un documentbuilder
			DocumentBuilder db = dbf.newDocumentBuilder();

			// parseamos el XML y obtenemos una representaci�n DOM
			dom = db.parse(fichero);
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

	}

	public void parseDocument() {
		
		Element docEle = dom.getDocumentElement();

		NodeList nl = docEle.getElementsByTagName("accion");
		if (nl != null && nl.getLength() > 0) {
			for (int i = 0; i < nl.getLength(); i++) {

				Element el = (Element) nl.item(i);			
							
				libro l = getLibro(el);

				libros.add(l);
			}
		}

	}

	private libro getLibro(Element elem) {
		String nombre = getTextValue(elem,"nombre");
		String compras = getCom(elem,"compra");
		String ventas = getVen(elem,"ventas");
		libro l = new libro(nombre,compras,ventas);

		return l;	
	}
	
	private String getTextValue(Element ele, String tagName) {
		String textVal = null;
		
		NodeList nl = ele.getElementsByTagName(tagName);
		for (int i = 0; i < nl.getLength(); i++) {
			Element el = (Element)nl.item(i);
			textVal = el.getFirstChild().getNodeValue();
			
		}		
		return textVal;
	}
	
	private String getCom(Element ele, String tagName) {
		String textVal1 = null;
		String comp=null;
		String res=null;
		String can=null;
		String pre=null;
		
		
		NodeList nl4 = ele.getElementsByTagName("compra");
		for (int k = 0; k < nl4.getLength(); k++) {
			Element el4 = (Element)nl4.item(k);
			
			NodeList nl5 = el4.getElementsByTagName("cantidad");
			for (int r = 0; r < nl5.getLength(); r++) {
				Element el5 = (Element)nl4.item(r);
				textVal1= el5.getFirstChild().getNodeValue();
				can="Cantidad: "+textVal1;
				
			}
			
			NodeList nl6 = el4.getElementsByTagName("precio");
			for (int r = 0; r < nl6.getLength(); r++) {
				Element el6 = (Element)nl4.item(r);
				textVal1= el6.getFirstChild().getNodeValue();				pre="Precio: "+textVal1;			
			}
		}
			
		comp= can+"\n"+pre;
			
		
		return comp;
	}			
	
	private String getVen(Element ele, String tagName) {
		String textVal1 = null;
		String comp=null;
		String vent=null;
		String res=null;
		String can=null;
		String pre=null;
		
		
		NodeList nl8 = ele.getElementsByTagName("venta");
		for (int k = 0; k < nl8.getLength(); k++) {
			Element el4 = (Element)nl8.item(k);
			
			NodeList nl5 = el4.getElementsByTagName("cantidad");
			for (int r = 0; r < nl5.getLength(); r++) {
				Element el5 = (Element)nl8.item(r);
				textVal1= el5.getFirstChild().getNodeValue();
				can="Cantidad: "+textVal1;
				
			}
			
			NodeList nl6 = el4.getElementsByTagName("precio");
			for (int r = 0; r < nl6.getLength(); r++) {
				Element el6 = (Element)nl8.item(r);
				textVal1= el6.getFirstChild().getNodeValue();
				pre="Precio: "+textVal1;			
			}
		}
			
		vent= can+"\n"+pre;			
		
		return vent;
	}			
	
	
	public void print(){

		Iterator it = libros.iterator();
		while(it.hasNext()) {
			libro l=(libro) it.next();
			l.print();
		}
	}

}
