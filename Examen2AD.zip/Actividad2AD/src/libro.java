import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class libro implements Serializable {
	
	
	private String nombre=null;
	private String compras=null;
	private String ventas=null;
	
	
	public libro() {
		
	}
	
	public libro(String t,String a,String e) {
		
		nombre=t;
		
		compras=e;
		
		ventas=a;
		
	}

	

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCompras() {
		return compras;
	}

	public void setCompras(String compras) {
		this.compras = compras;
	}

	public String getVentas() {
		return ventas;
	}

	public void setVentas(String ventas) {
		this.ventas = ventas;
	}

	public void print() {
		System.out.println("Nombre: " + nombre + "\nCompras: \n" + compras+"\nVentas: \n"+ventas);
	}


}
